import { Card, CardContent, Typography } from "@mui/material";
import React from "react";
import { useDispatch, useSelector } from "react-redux";

const Home = () => {
  const statesArray = useSelector((state) => state);
  console.log("object", statesArray.simple);
  return (
    <Card sx={{ maxWidth: 345 }} style={{margin: '10px'}}>
      {statesArray &&
        statesArray.simple.userData.map((ele) => {
          return (
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                {ele.email}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {ele.firstName} {ele.lastName}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {ele.DOB}
              </Typography>
            </CardContent>
          );
        })}
    </Card>
  );
};

export default Home;

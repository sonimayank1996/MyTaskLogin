export default (state = {}, action) => {
  console.log('state------', state)
  //  const newUser =  [state, action.payload]
    switch (action.type) {
     case 'SIMPLE_ACTION':
      return {
       userData: action.payload
      }
     default:
      return state
    }
   }
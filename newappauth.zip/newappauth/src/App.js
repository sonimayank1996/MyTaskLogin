import React, { useState } from "react";
import "./App.css";
import Login from "./Login";
import Signup from "./Signup";
import { Routes, Route, Router, useNavigate } from "react-router-dom";
import Home from "./Home";

function App() {
  const [authType, setAuthType] = useState("login");
  return (
    <div className="App">
       <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
        </Routes>
    </div>
  );
}

export default App;
